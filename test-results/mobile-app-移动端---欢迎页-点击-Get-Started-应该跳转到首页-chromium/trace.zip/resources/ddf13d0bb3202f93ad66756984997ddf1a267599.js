(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/lib_actions_notifications_ts_0aa9876f._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_e6c70351._.js",
  "static/chunks/node_modules_@base-ui_react_esm_52c18760._.js",
  "static/chunks/node_modules_82ad241e._.js",
  "static/chunks/_aa7dc073._.js"
],
    source: "dynamic"
});
